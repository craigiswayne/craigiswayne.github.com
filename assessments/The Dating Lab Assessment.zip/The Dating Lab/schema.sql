CREATE SCHEMA `assessments` ;
